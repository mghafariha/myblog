import React from 'react';
const AboutPage=()=>(
    <>
        <h1>About me</h1>
        <p>
            Welcome to my blog
        </p>
            <p>
                dhdfjj kkgkfgkfk fgkgfkg
            </p>
    </>
);
export default AboutPage;