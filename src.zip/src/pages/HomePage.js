import React from 'react';
const HomePage=()=>(
    <>
        <h1>Hello, Welcome to my blog</h1>
        <p>
            Welcome to my blog
        </p>
            <p>
                dhdfjj kkgkfgkfk fgkgfkg
            </p>
    </>
);
export default HomePage;