const articles=[{
  name:'article1',
  title:'article about nature',
  content:['ndnkfd fvdkmv  fdkdffjfjjfjfjfjfjjfjf', '123kgkl gkkgf fkffklkl']

}, {name:'article2',
    tilte:'article about Zoo',
   content:['ndnkfd fvdkmv  fdkdffjfjjfjfjfjfjjfjf', '123kgkl gkkgf fkffklkl']}]
export default articles;